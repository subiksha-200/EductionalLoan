package com.loan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EductionalLoanApplication {

	public static void main(String[] args) {
		SpringApplication.run(EductionalLoanApplication.class, args);
	}

}
