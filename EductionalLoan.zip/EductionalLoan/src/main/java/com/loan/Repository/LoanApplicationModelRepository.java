package com.loan.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.loan.Model.LoanApplicationModel;

public interface LoanApplicationModelRepository extends JpaRepository<LoanApplicationModel,Integer> {


}
