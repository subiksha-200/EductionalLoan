package com.loan.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.loan.Model.AdminModel;

public interface AdminRepository extends JpaRepository<AdminModel,Integer> {

}
