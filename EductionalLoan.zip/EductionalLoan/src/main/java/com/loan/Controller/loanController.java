package com.loan.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.loan.Model.LoanApplicationModel;
import com.loan.Model.UserModel;
import com.loan.Service.loanService;

@RestController
public class loanController {
@Autowired
loanService ls;
@GetMapping("user/getProfile")
public List<UserModel>getProfile(){
	return ls.getUser();
}
@PostMapping("/post")
public UserModel postProfile(@RequestBody UserModel a)
{
	return ls.addUser(a);
}
@PutMapping("/put")
public UserModel updateProfile(@RequestBody UserModel b){
	return ls.updateUser(b);
}
@DeleteMapping("/deleteid/{id}")
public String deleteProfile(@PathVariable int id)
{
	return ls.deleteUser(id);
}
@GetMapping("/getloan")
public List<LoanApplicationModel> getProfile1(){
	return ls.getUser1();
}
@PostMapping("/postloan")
public LoanApplicationModel postProfile1(@RequestBody LoanApplicationModel a)
{
	return ls.addUser1(a);
}
@PutMapping("/putloan")
public LoanApplicationModel updateProfile1(@RequestBody LoanApplicationModel b){
	return ls.updateUser1(b);
}
@DeleteMapping("/deleteloanid/{loanId}")
public String deleteProfile1(@PathVariable int loanId)
{
	return ls.deleteUser1(loanId);
}


}
