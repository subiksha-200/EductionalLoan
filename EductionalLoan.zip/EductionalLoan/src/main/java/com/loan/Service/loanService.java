package com.loan.Service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.loan.Model.LoanApplicationModel;
import com.loan.Model.UserModel;
import com.loan.Repository.AdminRepository;
import com.loan.Repository.LoanApplicationModelRepository;
import com.loan.Repository.LoginModelRepository;
import com.loan.Repository.UserModelRepository;

@Service
public class loanService {
@Autowired
 AdminRepository ar;
@Autowired
 LoanApplicationModelRepository la;
@Autowired
 LoginModelRepository lm;
@Autowired
 UserModelRepository us;
 public List <UserModel> getUser(){
	 return us.findAll();
 }
 public UserModel addUser(UserModel a) {
	 return us.save(a);
 }
 public UserModel updateUser(UserModel b) {
	 return us.save(b);
 }
 public String deleteUser(int id) {
	 us.deleteById(id);
	 return id+"id has been deleted";
 }
 public List <LoanApplicationModel> getUser1(){
	 return la.findAll();
 }
 public LoanApplicationModel addUser1(LoanApplicationModel a) {
	 return la.save(a);
 }
 public LoanApplicationModel updateUser1(LoanApplicationModel b) {
	 return la.save(b);
 }
 public String deleteUser1(int loanId) {
	 la.deleteById(loanId);
	 return loanId+"id has been deleted";
 }

}
